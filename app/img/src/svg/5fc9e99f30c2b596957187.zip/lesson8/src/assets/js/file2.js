console.log('file 2');
